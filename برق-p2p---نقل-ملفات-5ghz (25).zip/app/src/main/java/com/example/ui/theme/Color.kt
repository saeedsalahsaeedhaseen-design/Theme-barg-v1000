package com.example.ui.theme

import android.content.Context
import android.content.res.Configuration
import android.provider.Settings
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.LayoutDirection
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min

enum class BarqThemeId(
    val storageKey: String,
    val englishTitle: String,
    val arabicTitle: String,
    val subtitle: String,
    val isLightByDefault: Boolean = false
) {
    // Original 9 Themes (IDs and storageKeys preserved 100%)
    MIDNIGHT_BLUE(
        storageKey = "MIDNIGHT_BLUE",
        englishTitle = "Midnight Blue",
        arabicTitle = "أزرق منتصف الليل (الافتراضي)",
        subtitle = "هوية برق الأصلية بخلفية ليلية عميقة وتوهج السيان والزمرد"
    ),
    CYBERPUNK(
        storageKey = "CYBERPUNK",
        englishTitle = "Cyberpunk",
        arabicTitle = "سايبربانك نيون",
        subtitle = "أرجواني ليلي مشبع مع فوشيا نيون وأصفر كهربائي عالي التباين"
    ),
    PURE_LIGHT(
        storageKey = "PURE_LIGHT",
        englishTitle = "Pure Light",
        arabicTitle = "نهاري نقي (Pure Light)",
        subtitle = "واجهة فاتحة نقية بنصوص داكنة فائقة الوضوح تحت أشعة الشمس",
        isLightByDefault = true
    ),
    EMERALD(
        storageKey = "EMERALD",
        englishTitle = "Emerald",
        arabicTitle = "الزمرد الملكي",
        subtitle = "أخضر زمردي عميق مريح للعين مع لمسات نعناعية وذهبية"
    ),
    LUXURY_GOLD(
        storageKey = "LUXURY_GOLD",
        englishTitle = "Luxury Gold",
        arabicTitle = "الذهب الفاخر",
        subtitle = "أسود أونيكس ملكي مع تدرجات الذهب الخالص والكهرمان الدافئ"
    ),
    GLASSMORPHISM(
        storageKey = "GLASSMORPHISM",
        englishTitle = "Glassmorphism",
        arabicTitle = "بلوري زجاجي (Glass)",
        subtitle = "أسطح زجاجية ثلجية شفافة مع حدود سماوية مضيئة"
    ),
    CRIMSON(
        storageKey = "CRIMSON",
        englishTitle = "Crimson",
        arabicTitle = "القرمزي الناري",
        subtitle = "أحمر قرمزي داكن مع توهج ياقوتي وبرتقالي نابض"
    ),
    GRAPHITE(
        storageKey = "GRAPHITE",
        englishTitle = "Graphite",
        arabicTitle = "الجرافيت المعدني",
        subtitle = "رمادي تيتانيوم هندسي مع أزرق فولاذي هادئ وتباين متوازن"
    ),
    // 18 New Static Themes
    ARCTIC_ICE(
        storageKey = "ARCTIC_ICE",
        englishTitle = "Arctic Ice",
        arabicTitle = "الجليد القطبي (Arctic Ice)",
        subtitle = "أزرق جليدي نقي وأبيض ثلجي مشرق بتفاصيل كريستالية واضحة",
        isLightByDefault = true
    ),
    OCEAN_DEEP(
        storageKey = "OCEAN_DEEP",
        englishTitle = "Ocean Deep",
        arabicTitle = "أعماق المحيط (Ocean Deep)",
        subtitle = "أزرق بحري سحيق مع توهج سماوي وفيروزي مستوحى من أعماق البحر"
    ),
    SUNSET(
        storageKey = "SUNSET",
        englishTitle = "Sunset",
        arabicTitle = "غروب الشمس (Sunset)",
        subtitle = "تدرجات الغروب الدافئة من البرتقالي والوردي والبنفسجي الغسقي"
    ),
    AURORA(
        storageKey = "AURORA",
        englishTitle = "Aurora",
        arabicTitle = "الشفق القطبي (Aurora)",
        subtitle = "تناغم الشفق القطبي بين الأخضر الزمردي والسماوي والبنفسجي"
    ),
    ROYAL_PURPLE(
        storageKey = "ROYAL_PURPLE",
        englishTitle = "Royal Purple",
        arabicTitle = "البنفسجي الملكي (Royal Purple)",
        subtitle = "بنفسجي ملكي فاخر مطعّم بلمسات الذهب الخالص والأرجوان"
    ),
    ROSE_PINK(
        storageKey = "ROSE_PINK",
        englishTitle = "Rose Pink",
        arabicTitle = "الوردي الناعم (Rose Pink)",
        subtitle = "درجات الوردي الأنيق والوردي الفاتح المشرق بتباين مريح"
    ),
    NEON_GREEN(
        storageKey = "NEON_GREEN",
        englishTitle = "Neon Green",
        arabicTitle = "الأخضر النيون (Neon Green)",
        subtitle = "أخضر نيون رقمي ساطع على خلفية سوداء فاحمة عالية التباين"
    ),
    SAPPHIRE(
        storageKey = "SAPPHIRE",
        englishTitle = "Sapphire",
        arabicTitle = "الياقوت الأزرق (Sapphire)",
        subtitle = "أزرق ياقوتي ملكي عميق مع حواف مضيئة وتفاصيل بلورية"
    ),
    RUBY_RED(
        storageKey = "RUBY_RED",
        englishTitle = "Ruby Red",
        arabicTitle = "الياقوت الأحمر (Ruby Red)",
        subtitle = "أحمر ياقوتي متوهج مع أسود أونيكس فخم وتفاصيل دافئة"
    ),
    AMETHYST(
        storageKey = "AMETHYST",
        englishTitle = "Amethyst",
        arabicTitle = "الجمشت الأرجواني (Amethyst)",
        subtitle = "بنفسجي جمشتي غني مع أرجواني متألق ولمسات وردية"
    ),
    SILVER(
        storageKey = "SILVER",
        englishTitle = "Silver",
        arabicTitle = "الفضي المعدني (Silver)",
        subtitle = "فضي معدني عصري ورمادي نقي مع تفاصيل فولاذية واضحة",
        isLightByDefault = true
    ),
    COPPER(
        storageKey = "COPPER",
        englishTitle = "Copper",
        arabicTitle = "النحاسي الدافئ (Copper)",
        subtitle = "نحاسي مصقول مع درجات البني والبرونز الدافئ والذهب"
    ),
    LAVENDER(
        storageKey = "LAVENDER",
        englishTitle = "Lavender",
        arabicTitle = "اللافندر الهادئ (Lavender)",
        subtitle = "بنفسجي لافندر فاتح وأبيض ناعم مريح للعين في الإضاءة النهارية",
        isLightByDefault = true
    ),
    MINT(
        storageKey = "MINT",
        englishTitle = "Mint",
        arabicTitle = "النعناع المنعش (Mint)",
        subtitle = "أخضر نعناعي منعش مع خلفية داكنة هادئة وتفاصيل فيروزية"
    ),
    CHERRY_BLOSSOM(
        storageKey = "CHERRY_BLOSSOM",
        englishTitle = "Cherry Blossom",
        arabicTitle = "زهر الكرز (Cherry Blossom)",
        subtitle = "وردي زهر الكرز الرقيق مع أبيض ناصع وتباين ناعم وأنيق",
        isLightByDefault = true
    ),
    MIDNIGHT_BLACK(
        storageKey = "MIDNIGHT_BLACK",
        englishTitle = "Midnight Black",
        arabicTitle = "الأسود العميق (Midnight Black)",
        subtitle = "أسود عميق لشاشات OLED مع تفاصيل وحدود مضيئة عالية الدقة"
    ),
    DESERT_SAND(
        storageKey = "DESERT_SAND",
        englishTitle = "Desert Sand",
        arabicTitle = "رمال الصحراء (Desert Sand)",
        subtitle = "رملي صحراوي دافئ وذهبي عربي أصيل مع وضوح نهاري ممتاز",
        isLightByDefault = true
    ),
    GALAXY(
        storageKey = "GALAXY",
        englishTitle = "Galaxy",
        arabicTitle = "المجرة الفضائية (Galaxy)",
        subtitle = "ألوان الفضاء العميق البنفسجية والزرقاء مع توهج السديم الكوني"
    ),
    CUSTOM(
        storageKey = "CUSTOM",
        englishTitle = "Custom",
        arabicTitle = "مخصص (لوحة ألوان كاملة)",
        subtitle = "تصميم لوني حر بالكامل لجميع عناصر الواجهة مع ضمان وضوح النصوص"
    );

    companion object {
        fun fromKey(key: String?): BarqThemeId {
            return entries.find { it.storageKey.equals(key, ignoreCase = true) } ?: MIDNIGHT_BLUE
        }
    }
}

enum class BarqAnimatedThemeId(
    val storageKey: String,
    val englishTitle: String,
    val arabicTitle: String,
    val subtitle: String,
    val baseThemeId: BarqThemeId
) {
    NONE(
        storageKey = "NONE",
        englishTitle = "Static / Custom",
        arabicTitle = "بدون حركة (ثابت)",
        subtitle = "استخدام الثيم الثابت أو المخصص المختار بدون تحريك لوني",
        baseThemeId = BarqThemeId.MIDNIGHT_BLUE
    ),
    AURORA_FLOW(
        storageKey = "AURORA_FLOW",
        englishTitle = "Aurora Flow",
        arabicTitle = "تدفق الشفق القطبي (Aurora Flow)",
        subtitle = "تدرجات الشفق القطبي المتحركة بنعومة بين الأخضر الزمردي والسماوي والبنفسجي",
        baseThemeId = BarqThemeId.AURORA
    ),
    GALAXY_MOTION(
        storageKey = "GALAXY_MOTION",
        englishTitle = "Galaxy Motion",
        arabicTitle = "حركة المجرة والنجوم (Galaxy Motion)",
        subtitle = "نجوم وتأثيرات فضائية متحركة بين البنفسجي الكوني والأزرق السديمي",
        baseThemeId = BarqThemeId.GALAXY
    ),
    CYBER_PULSE(
        storageKey = "CYBER_PULSE",
        englishTitle = "Cyber Pulse",
        arabicTitle = "نبض السايبربانك (Cyber Pulse)",
        subtitle = "نبضات نيون بنفسجية وسماوية وفوشيا متزامنة بأسلوب مستقبلي",
        baseThemeId = BarqThemeId.CYBERPUNK
    ),
    OCEAN_WAVES(
        storageKey = "OCEAN_WAVES",
        englishTitle = "Ocean Waves",
        arabicTitle = "أمواج المحيط (Ocean Waves)",
        subtitle = "موجات وتدرجات بحرية زرقاء وفيروزية متحركة بانسيابية هادئة",
        baseThemeId = BarqThemeId.OCEAN_DEEP
    ),
    NEON_SPECTRUM(
        storageKey = "NEON_SPECTRUM",
        englishTitle = "Neon Spectrum",
        arabicTitle = "طيف النيون (Neon Spectrum)",
        subtitle = "انتقال سلس ومتناغم بين ألوان الطيف النيون على خلفية داكنة",
        baseThemeId = BarqThemeId.NEON_GREEN
    ),
    SUNSET_MOTION(
        storageKey = "SUNSET_MOTION",
        englishTitle = "Sunset Motion",
        arabicTitle = "حركة الغروب (Sunset Motion)",
        subtitle = "تدرجات غروب الشمس الدافئة المتحركة بين البرتقالي والوردي والأرجواني",
        baseThemeId = BarqThemeId.SUNSET
    ),
    EMERALD_PULSE(
        storageKey = "EMERALD_PULSE",
        englishTitle = "Emerald Pulse",
        arabicTitle = "نبض الزمرد (Emerald Pulse)",
        subtitle = "توهج أخضر زمردي ونعناعي متحرك يمنح الواجهة طابعاً حيوياً",
        baseThemeId = BarqThemeId.EMERALD
    ),
    GOLDEN_LUXURY(
        storageKey = "GOLDEN_LUXURY",
        englishTitle = "Golden Luxury",
        arabicTitle = "الفخامة الذهبية (Golden Luxury)",
        subtitle = "لمعان ذهبي ملكي وكهرماني متحرك على خلفية أونيكس فاخرة",
        baseThemeId = BarqThemeId.LUXURY_GOLD
    ),
    RAINBOW_FLOW(
        storageKey = "RAINBOW_FLOW",
        englishTitle = "Rainbow Flow",
        arabicTitle = "تدفق قوس قزح (Rainbow Flow)",
        subtitle = "تدرجات قوس قزح الاحترافية الناعمة والمتدفقة مع ثبات وضوح النصوص",
        baseThemeId = BarqThemeId.GLASSMORPHISM
    ),
    FLAME_MOTION(
        storageKey = "FLAME_MOTION",
        englishTitle = "Flame Motion",
        arabicTitle = "حركة اللهب (Flame Motion)",
        subtitle = "تدرجات حمراء وبرتقالية وذهبية نارية متحركة بنعومة واحترافية",
        baseThemeId = BarqThemeId.CRIMSON
    );

    companion object {
        val animatedPresets: List<BarqAnimatedThemeId>
            get() = entries.filter { it != NONE }

        fun fromKey(key: String?): BarqAnimatedThemeId {
            return entries.find { it.storageKey.equals(key, ignoreCase = true) } ?: NONE
        }
    }
}

enum class BarqAnimationSpeed(
    val storageKey: String,
    val arabicLabel: String,
    val englishLabel: String,
    val cycleDurationMillis: Int
) {
    SLOW(
        storageKey = "SLOW",
        arabicLabel = "بطيئة",
        englishLabel = "Slow",
        cycleDurationMillis = 9000
    ),
    MEDIUM(
        storageKey = "MEDIUM",
        arabicLabel = "متوسطة",
        englishLabel = "Medium",
        cycleDurationMillis = 5200
    ),
    FAST(
        storageKey = "FAST",
        arabicLabel = "سريعة",
        englishLabel = "Fast",
        cycleDurationMillis = 2600
    );

    companion object {
        fun fromKey(key: String?): BarqAnimationSpeed {
            return entries.find { it.storageKey.equals(key, ignoreCase = true) } ?: MEDIUM
        }
    }
}

enum class BarqThemeBrightnessMode(
    val storageKey: String,
    val arabicLabel: String
) {
    THEME_DEFAULT("THEME_DEFAULT", "الافتراضي للثيم"),
    DARK("DARK", "داكن دائماً"),
    LIGHT("LIGHT", "فاتح دائماً");

    companion object {
        fun fromKey(key: String?): BarqThemeBrightnessMode {
            return entries.find { it.storageKey.equals(key, ignoreCase = true) } ?: THEME_DEFAULT
        }
    }
}

@Immutable
data class BarqThemePalette(
    val themeId: BarqThemeId,
    val background: Color,
    val surface: Color,
    val card: Color,
    val cardElevated: Color,
    val border: Color,
    val primaryAccent: Color,
    val primaryAccentDim: Color,
    val secondaryAccent: Color,
    val secondaryAccentDim: Color,
    val tertiaryAccent: Color,
    val tertiarySoft: Color,
    val dangerAccent: Color,
    val highlightAccent: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val isLight: Boolean,
    val buttonColor: Color = primaryAccent
) {
    val onPrimaryAccent: Color
        get() = highContrastTextFor(primaryAccent)

    val onSecondaryAccent: Color
        get() = highContrastTextFor(secondaryAccent)

    val onTertiaryAccent: Color
        get() = highContrastTextFor(tertiaryAccent)

    val onButtonColor: Color
        get() = highContrastTextFor(buttonColor)

    val contrastRatioPrimaryText: Double
        get() = calculateContrastRatio(textPrimary, card)
}

fun highContrastTextFor(backgroundColor: Color): Color {
    val darkCandidate = Color(0xFF050A12)
    val lightCandidate = Color(0xFFFFFFFF)
    val darkContrast = calculateContrastRatio(darkCandidate, backgroundColor)
    val lightContrast = calculateContrastRatio(lightCandidate, backgroundColor)
    return if (darkContrast >= lightContrast) {
        if (darkContrast >= 4.5) darkCandidate else Color(0xFF000000)
    } else {
        lightCandidate
    }
}

fun calculateContrastRatio(foreground: Color, background: Color): Double {
    val l1 = foreground.luminance().toDouble()
    val l2 = background.luminance().toDouble()
    val brightest = max(l1, l2)
    val darkest = min(l1, l2)
    return (brightest + 0.05) / (darkest + 0.05)
}

internal fun shiftColorBrightness(color: Color, factor: Float): Color {
    val r = (color.red * factor).coerceIn(0f, 1f)
    val g = (color.green * factor).coerceIn(0f, 1f)
    val b = (color.blue * factor).coerceIn(0f, 1f)
    return Color(r, g, b, 1f)
}

internal fun blendColors(c1: Color, c2: Color, ratioC2: Float): Color {
    val rRatio = ratioC2.coerceIn(0f, 1f)
    val inv = 1f - rRatio
    return Color(
        red = (c1.red * inv + c2.red * rRatio).coerceIn(0f, 1f),
        green = (c1.green * inv + c2.green * rRatio).coerceIn(0f, 1f),
        blue = (c1.blue * inv + c2.blue * rRatio).coerceIn(0f, 1f),
        alpha = 1f
    )
}

fun lerpPalette(start: BarqThemePalette, end: BarqThemePalette, fraction: Float): BarqThemePalette {
    val t = fraction.coerceIn(0f, 1f)
    // Smooth cosine interpolation for organic transitions
    val smoothT = ((1.0 - cos(t * PI)) / 2.0).toFloat().coerceIn(0f, 1f)
    return start.copy(
        background = blendColors(start.background, end.background, smoothT),
        surface = blendColors(start.surface, end.surface, smoothT),
        card = blendColors(start.card, end.card, smoothT),
        cardElevated = blendColors(start.cardElevated, end.cardElevated, smoothT),
        border = blendColors(start.border, end.border, smoothT),
        primaryAccent = blendColors(start.primaryAccent, end.primaryAccent, smoothT),
        primaryAccentDim = blendColors(start.primaryAccentDim, end.primaryAccentDim, smoothT),
        secondaryAccent = blendColors(start.secondaryAccent, end.secondaryAccent, smoothT),
        secondaryAccentDim = blendColors(start.secondaryAccentDim, end.secondaryAccentDim, smoothT),
        tertiaryAccent = blendColors(start.tertiaryAccent, end.tertiaryAccent, smoothT),
        tertiarySoft = blendColors(start.tertiarySoft, end.tertiarySoft, smoothT),
        dangerAccent = blendColors(start.dangerAccent, end.dangerAccent, smoothT),
        highlightAccent = blendColors(start.highlightAccent, end.highlightAccent, smoothT),
        textPrimary = blendColors(start.textPrimary, end.textPrimary, smoothT),
        textSecondary = blendColors(start.textSecondary, end.textSecondary, smoothT),
        textMuted = blendColors(start.textMuted, end.textMuted, smoothT),
        buttonColor = blendColors(start.buttonColor, end.buttonColor, smoothT)
    )
}

/**
 * Adapts any BarqThemePalette to Light or Dark mode when the user overrides brightness mode,
 * preserving the theme's signature accents while guaranteeing high readability.
 */
fun adaptPaletteForBrightness(palette: BarqThemePalette, targetIsLight: Boolean): BarqThemePalette {
    if (palette.isLight == targetIsLight) return palette
    return if (targetIsLight) {
        val bg = blendColors(Color(0xFFF4F7FB), palette.primaryAccent, 0.05f)
        val surf = Color(0xFFFFFFFF)
        val cardCol = blendColors(Color(0xFFFFFFFF), palette.primaryAccent, 0.03f)
        val cardElev = blendColors(Color(0xFFE8EEF5), palette.primaryAccent, 0.08f)
        val borderCol = blendColors(Color(0xFFCBD5E1), palette.primaryAccent, 0.32f)
        val prim = if (palette.primaryAccent.luminance() > 0.65f) {
            shiftColorBrightness(palette.primaryAccent, 0.72f)
        } else {
            palette.primaryAccent
        }
        val sec = if (palette.secondaryAccent.luminance() > 0.65f) {
            shiftColorBrightness(palette.secondaryAccent, 0.72f)
        } else {
            palette.secondaryAccent
        }
        palette.copy(
            background = bg,
            surface = surf,
            card = cardCol,
            cardElevated = cardElev,
            border = borderCol,
            primaryAccent = prim,
            primaryAccentDim = shiftColorBrightness(prim, 0.78f),
            secondaryAccent = sec,
            secondaryAccentDim = shiftColorBrightness(sec, 0.78f),
            tertiarySoft = Color(0xFFFEF3C7),
            textPrimary = Color(0xFF0F172A),
            textSecondary = Color(0xFF334155),
            textMuted = Color(0xFF64748B),
            isLight = true,
            buttonColor = prim
        )
    } else {
        val bg = blendColors(Color(0xFF070C17), palette.primaryAccent, 0.06f)
        val surf = blendColors(Color(0xFF0E1626), palette.primaryAccent, 0.08f)
        val cardCol = blendColors(Color(0xFF152036), palette.primaryAccent, 0.10f)
        val cardElev = blendColors(Color(0xFF1E2D4A), palette.primaryAccent, 0.14f)
        val borderCol = blendColors(Color(0xFF2B3F66), palette.primaryAccent, 0.38f)
        val prim = if (palette.primaryAccent.luminance() < 0.18f) {
            blendColors(palette.primaryAccent, Color.White, 0.35f)
        } else {
            palette.primaryAccent
        }
        val sec = if (palette.secondaryAccent.luminance() < 0.18f) {
            blendColors(palette.secondaryAccent, Color.White, 0.35f)
        } else {
            palette.secondaryAccent
        }
        palette.copy(
            background = bg,
            surface = surf,
            card = cardCol,
            cardElevated = cardElev,
            border = borderCol,
            primaryAccent = prim,
            primaryAccentDim = shiftColorBrightness(prim, 0.75f),
            secondaryAccent = sec,
            secondaryAccentDim = shiftColorBrightness(sec, 0.75f),
            tertiarySoft = Color(0xFF3B2A10),
            textPrimary = Color(0xFFF8FAFC),
            textSecondary = Color(0xFFCBD5E1),
            textMuted = Color(0xFF94A3B8),
            isLight = false,
            buttonColor = prim
        )
    }
}

object BarqThemePalettes {
    // 1. Midnight Blue (Default)
    val MidnightBlue = BarqThemePalette(
        themeId = BarqThemeId.MIDNIGHT_BLUE,
        background = Color(0xFF060B16),
        surface = Color(0xFF0D1628),
        card = Color(0xFF131F38),
        cardElevated = Color(0xFF1A2A4A),
        border = Color(0xFF263B63),
        primaryAccent = Color(0xFF00E5FF),
        primaryAccentDim = Color(0xFF0088A3),
        secondaryAccent = Color(0xFF10B981),
        secondaryAccentDim = Color(0xFF056C4B),
        tertiaryAccent = Color(0xFFF59E0B),
        tertiarySoft = Color(0xFF3B2A10),
        dangerAccent = Color(0xFFF43F5E),
        highlightAccent = Color(0xFF8B5CF6),
        textPrimary = Color(0xFFF8FAFC),
        textSecondary = Color(0xFF94A3B8),
        textMuted = Color(0xFF64748B),
        isLight = false
    )

    // 2. Cyberpunk
    val Cyberpunk = BarqThemePalette(
        themeId = BarqThemeId.CYBERPUNK,
        background = Color(0xFF090414),
        surface = Color(0xFF130926),
        card = Color(0xFF1D0E38),
        cardElevated = Color(0xFF2A1550),
        border = Color(0xFF5B21B6),
        primaryAccent = Color(0xFFFF2A85),
        primaryAccentDim = Color(0xFFBE185D),
        secondaryAccent = Color(0xFF00F0FF),
        secondaryAccentDim = Color(0xFF0891B2),
        tertiaryAccent = Color(0xFFFCEE09),
        tertiarySoft = Color(0xFF3B3506),
        dangerAccent = Color(0xFFFF4D6D),
        highlightAccent = Color(0xFFA855F7),
        textPrimary = Color(0xFFFDF4FF),
        textSecondary = Color(0xFFD8B4FE),
        textMuted = Color(0xFFA78BFA),
        isLight = false
    )

    // 3. Pure Light
    val PureLight = BarqThemePalette(
        themeId = BarqThemeId.PURE_LIGHT,
        background = Color(0xFFF1F5F9),
        surface = Color(0xFFFFFFFF),
        card = Color(0xFFFFFFFF),
        cardElevated = Color(0xFFE2E8F0),
        border = Color(0xFFCBD5E1),
        primaryAccent = Color(0xFF0284C7),
        primaryAccentDim = Color(0xFF0369A1),
        secondaryAccent = Color(0xFF059669),
        secondaryAccentDim = Color(0xFF047857),
        tertiaryAccent = Color(0xFFD97706),
        tertiarySoft = Color(0xFFFEF3C7),
        dangerAccent = Color(0xFFE11D48),
        highlightAccent = Color(0xFF7C3AED),
        textPrimary = Color(0xFF0F172A),
        textSecondary = Color(0xFF334155),
        textMuted = Color(0xFF64748B),
        isLight = true
    )

    // 4. Emerald
    val Emerald = BarqThemePalette(
        themeId = BarqThemeId.EMERALD,
        background = Color(0xFF031410),
        surface = Color(0xFF07221B),
        card = Color(0xFF0C3027),
        cardElevated = Color(0xFF134236),
        border = Color(0xFF1E5E4D),
        primaryAccent = Color(0xFF10B981),
        primaryAccentDim = Color(0xFF059669),
        secondaryAccent = Color(0xFF34D399),
        secondaryAccentDim = Color(0xFF047857),
        tertiaryAccent = Color(0xFFFBBF24),
        tertiarySoft = Color(0xFF3A2C0A),
        dangerAccent = Color(0xFFF43F5E),
        highlightAccent = Color(0xFF2DD4BF),
        textPrimary = Color(0xFFECFDF5),
        textSecondary = Color(0xFFA7F3D0),
        textMuted = Color(0xFF6EE7B7),
        isLight = false
    )

    // 5. Luxury Gold
    val LuxuryGold = BarqThemePalette(
        themeId = BarqThemeId.LUXURY_GOLD,
        background = Color(0xFF0C0A06),
        surface = Color(0xFF17130B),
        card = Color(0xFF221C11),
        cardElevated = Color(0xFF302718),
        border = Color(0xFF5C4822),
        primaryAccent = Color(0xFFF59E0B),
        primaryAccentDim = Color(0xFFB45309),
        secondaryAccent = Color(0xFFFBBF24),
        secondaryAccentDim = Color(0xFF92400E),
        tertiaryAccent = Color(0xFFEAB308),
        tertiarySoft = Color(0xFF3B2E0D),
        dangerAccent = Color(0xFFEF4444),
        highlightAccent = Color(0xFFFDE047),
        textPrimary = Color(0xFFFFFBEB),
        textSecondary = Color(0xFFFDE68A),
        textMuted = Color(0xFFD97706),
        isLight = false
    )

    // 6. Glassmorphism
    val Glassmorphism = BarqThemePalette(
        themeId = BarqThemeId.GLASSMORPHISM,
        background = Color(0xFF081426),
        surface = Color(0xFF102340),
        card = Color(0xFF173156),
        cardElevated = Color(0xFF204170),
        border = Color(0xFF38BDF8),
        primaryAccent = Color(0xFF38BDF8),
        primaryAccentDim = Color(0xFF0284C7),
        secondaryAccent = Color(0xFF2DD4BF),
        secondaryAccentDim = Color(0xFF0D9488),
        tertiaryAccent = Color(0xFFF472B6),
        tertiarySoft = Color(0xFF3B152B),
        dangerAccent = Color(0xFFFB7185),
        highlightAccent = Color(0xFF818CF8),
        textPrimary = Color(0xFFF0F9FF),
        textSecondary = Color(0xFFBAE6FD),
        textMuted = Color(0xFF7DD3FC),
        isLight = false
    )

    // 7. Crimson
    val Crimson = BarqThemePalette(
        themeId = BarqThemeId.CRIMSON,
        background = Color(0xFF140609),
        surface = Color(0xFF240B11),
        card = Color(0xFF331019),
        cardElevated = Color(0xFF471623),
        border = Color(0xFF881337),
        primaryAccent = Color(0xFFF43F5E),
        primaryAccentDim = Color(0xFFBE123C),
        secondaryAccent = Color(0xFFFB923C),
        secondaryAccentDim = Color(0xFFC2410C),
        tertiaryAccent = Color(0xFFFBBF24),
        tertiarySoft = Color(0xFF3E2408),
        dangerAccent = Color(0xFFFF2E4C),
        highlightAccent = Color(0xFFE879F9),
        textPrimary = Color(0xFFFFF1F2),
        textSecondary = Color(0xFFFECDD3),
        textMuted = Color(0xFFFDA4AF),
        isLight = false
    )

    // 8. Graphite
    val Graphite = BarqThemePalette(
        themeId = BarqThemeId.GRAPHITE,
        background = Color(0xFF0F1115),
        surface = Color(0xFF181B22),
        card = Color(0xFF222630),
        cardElevated = Color(0xFF2D3240),
        border = Color(0xFF3F4759),
        primaryAccent = Color(0xFF60A5FA),
        primaryAccentDim = Color(0xFF2563EB),
        secondaryAccent = Color(0xFF34D399),
        secondaryAccentDim = Color(0xFF059669),
        tertiaryAccent = Color(0xFFFBBF24),
        tertiarySoft = Color(0xFF362A10),
        dangerAccent = Color(0xFFF87171),
        highlightAccent = Color(0xFFA78BFA),
        textPrimary = Color(0xFFF9FAFB),
        textSecondary = Color(0xFFD1D5DB),
        textMuted = Color(0xFF9CA3AF),
        isLight = false
    )

    // 9. Arctic Ice – أزرق جليدي وأبيض
    val ArcticIce = BarqThemePalette(
        themeId = BarqThemeId.ARCTIC_ICE,
        background = Color(0xFFEEF7FF),
        surface = Color(0xFFFFFFFF),
        card = Color(0xFFF8FCFF),
        cardElevated = Color(0xFFDCEEFF),
        border = Color(0xFF93C5FD),
        primaryAccent = Color(0xFF0284C7),
        primaryAccentDim = Color(0xFF0369A1),
        secondaryAccent = Color(0xFF0891B2),
        secondaryAccentDim = Color(0xFF0E7490),
        tertiaryAccent = Color(0xFF2563EB),
        tertiarySoft = Color(0xFFDBEAFE),
        dangerAccent = Color(0xFFE11D48),
        highlightAccent = Color(0xFF06B6D4),
        textPrimary = Color(0xFF082F49),
        textSecondary = Color(0xFF1E3A8A),
        textMuted = Color(0xFF475569),
        isLight = true
    )

    // 10. Ocean Deep – أزرق بحري وسماوي
    val OceanDeep = BarqThemePalette(
        themeId = BarqThemeId.OCEAN_DEEP,
        background = Color(0xFF030E1A),
        surface = Color(0xFF061A2E),
        card = Color(0xFF0B2742),
        cardElevated = Color(0xFF113659),
        border = Color(0xFF1D5B8C),
        primaryAccent = Color(0xFF00D4FF),
        primaryAccentDim = Color(0xFF0095B6),
        secondaryAccent = Color(0xFF06D6A0),
        secondaryAccentDim = Color(0xFF04966F),
        tertiaryAccent = Color(0xFF38BDF8),
        tertiarySoft = Color(0xFF0D2E47),
        dangerAccent = Color(0xFFFF5C77),
        highlightAccent = Color(0xFF48CAE4),
        textPrimary = Color(0xFFF0F9FF),
        textSecondary = Color(0xFFADE8F4),
        textMuted = Color(0xFF6497B1),
        isLight = false
    )

    // 11. Sunset – برتقالي ووردي وبنفسجي
    val Sunset = BarqThemePalette(
        themeId = BarqThemeId.SUNSET,
        background = Color(0xFF160814),
        surface = Color(0xFF240E21),
        card = Color(0xFF33152F),
        cardElevated = Color(0xFF451D40),
        border = Color(0xFF832B68),
        primaryAccent = Color(0xFFFF7B54),
        primaryAccentDim = Color(0xFFD9532F),
        secondaryAccent = Color(0xFFFF4D8D),
        secondaryAccentDim = Color(0xFFC82864),
        tertiaryAccent = Color(0xFFFFB26B),
        tertiarySoft = Color(0xFF422312),
        dangerAccent = Color(0xFFFF3B5C),
        highlightAccent = Color(0xFFC084FC),
        textPrimary = Color(0xFFFFF5F5),
        textSecondary = Color(0xFFFBCFE8),
        textMuted = Color(0xFFF472B6),
        isLight = false
    )

    // 12. Aurora – أخضر وسماوي وبنفسجي
    val Aurora = BarqThemePalette(
        themeId = BarqThemeId.AURORA,
        background = Color(0xFF051118),
        surface = Color(0xFF0A1D28),
        card = Color(0xFF102A3A),
        cardElevated = Color(0xFF183A4F),
        border = Color(0xFF246A73),
        primaryAccent = Color(0xFF2EE59D),
        primaryAccentDim = Color(0xFF16A36A),
        secondaryAccent = Color(0xFF00D2FF),
        secondaryAccentDim = Color(0xFF008FB3),
        tertiaryAccent = Color(0xFFA855F7),
        tertiarySoft = Color(0xFF2A1642),
        dangerAccent = Color(0xFFF43F5E),
        highlightAccent = Color(0xFF7F5AF0),
        textPrimary = Color(0xFFECFEFF),
        textSecondary = Color(0xFFA5F3FC),
        textMuted = Color(0xFF67E8F9),
        isLight = false
    )

    // 13. Royal Purple – بنفسجي ملكي وذهبي
    val RoyalPurple = BarqThemePalette(
        themeId = BarqThemeId.ROYAL_PURPLE,
        background = Color(0xFF0D061A),
        surface = Color(0xFF170B2C),
        card = Color(0xFF231142),
        cardElevated = Color(0xFF31195C),
        border = Color(0xFF5B2E9E),
        primaryAccent = Color(0xFFC084FC),
        primaryAccentDim = Color(0xFF9333EA),
        secondaryAccent = Color(0xFFFBBF24),
        secondaryAccentDim = Color(0xFFD97706),
        tertiaryAccent = Color(0xFFF59E0B),
        tertiarySoft = Color(0xFF3D280A),
        dangerAccent = Color(0xFFFB7185),
        highlightAccent = Color(0xFFE9D5FF),
        textPrimary = Color(0xFFFAF5FF),
        textSecondary = Color(0xFFE9D5FF),
        textMuted = Color(0xFFC084FC),
        isLight = false
    )

    // 14. Rose Pink – وردي ووردي فاتح
    val RosePink = BarqThemePalette(
        themeId = BarqThemeId.ROSE_PINK,
        background = Color(0xFF180710),
        surface = Color(0xFF280D1B),
        card = Color(0xFF381327),
        cardElevated = Color(0xFF4D1A36),
        border = Color(0xFF9D174D),
        primaryAccent = Color(0xFFFF6B9D),
        primaryAccentDim = Color(0xFFDB2777),
        secondaryAccent = Color(0xFFFF9EBB),
        secondaryAccentDim = Color(0xFFEC4899),
        tertiaryAccent = Color(0xFFF472B6),
        tertiarySoft = Color(0xFF4A1532),
        dangerAccent = Color(0xFFFF3355),
        highlightAccent = Color(0xFFFBCFE8),
        textPrimary = Color(0xFFFFF1F6),
        textSecondary = Color(0xFFFCE7F3),
        textMuted = Color(0xFFF9A8D4),
        isLight = false
    )

    // 15. Neon Green – أخضر نيون وأسود
    val NeonGreen = BarqThemePalette(
        themeId = BarqThemeId.NEON_GREEN,
        background = Color(0xFF040805),
        surface = Color(0xFF09120B),
        card = Color(0xFF0E1D12),
        cardElevated = Color(0xFF152B1B),
        border = Color(0xFF22C55E),
        primaryAccent = Color(0xFF39FF14),
        primaryAccentDim = Color(0xFF16A34A),
        secondaryAccent = Color(0xFF00F5D4),
        secondaryAccentDim = Color(0xFF0D9488),
        tertiaryAccent = Color(0xFFA3E635),
        tertiarySoft = Color(0xFF1E330A),
        dangerAccent = Color(0xFFFF4757),
        highlightAccent = Color(0xFF4ADE80),
        textPrimary = Color(0xFFF0FDF4),
        textSecondary = Color(0xFFBBF7D0),
        textMuted = Color(0xFF4ADE80),
        isLight = false
    )

    // 16. Sapphire – أزرق ياقوتي
    val Sapphire = BarqThemePalette(
        themeId = BarqThemeId.SAPPHIRE,
        background = Color(0xFF040A1E),
        surface = Color(0xFF091436),
        card = Color(0xFF102052),
        cardElevated = Color(0xFF182F73),
        border = Color(0xFF2563EB),
        primaryAccent = Color(0xFF60A5FA),
        primaryAccentDim = Color(0xFF2563EB),
        secondaryAccent = Color(0xFF38BDF8),
        secondaryAccentDim = Color(0xFF0284C7),
        tertiaryAccent = Color(0xFF818CF8),
        tertiarySoft = Color(0xFF1E265C),
        dangerAccent = Color(0xFFF43F5E),
        highlightAccent = Color(0xFF93C5FD),
        textPrimary = Color(0xFFEFF6FF),
        textSecondary = Color(0xFFBFDBFE),
        textMuted = Color(0xFF93C5FD),
        isLight = false
    )

    // 17. Ruby Red – أحمر ياقوتي وأسود
    val RubyRed = BarqThemePalette(
        themeId = BarqThemeId.RUBY_RED,
        background = Color(0xFF0B0406),
        surface = Color(0xFF17070B),
        card = Color(0xFF260B12),
        cardElevated = Color(0xFF38101A),
        border = Color(0xFF9F1239),
        primaryAccent = Color(0xFFFF3355),
        primaryAccentDim = Color(0xFFE11D48),
        secondaryAccent = Color(0xFFFF758F),
        secondaryAccentDim = Color(0xFFBE123C),
        tertiaryAccent = Color(0xFFFBBF24),
        tertiarySoft = Color(0xFF3B2408),
        dangerAccent = Color(0xFFFF1F40),
        highlightAccent = Color(0xFFFB7185),
        textPrimary = Color(0xFFFFF1F2),
        textSecondary = Color(0xFFFECDD3),
        textMuted = Color(0xFFFDA4AF),
        isLight = false
    )

    // 18. Amethyst – بنفسجي وأرجواني
    val Amethyst = BarqThemePalette(
        themeId = BarqThemeId.AMETHYST,
        background = Color(0xFF11071C),
        surface = Color(0xFF1C0D2E),
        card = Color(0xFF281342),
        cardElevated = Color(0xFF371B59),
        border = Color(0xFF6D28D9),
        primaryAccent = Color(0xFFD8B4FE),
        primaryAccentDim = Color(0xFF9333EA),
        secondaryAccent = Color(0xFFF0ABFC),
        secondaryAccentDim = Color(0xFFC026D3),
        tertiaryAccent = Color(0xFF38BDF8),
        tertiarySoft = Color(0xFF162C46),
        dangerAccent = Color(0xFFFB7185),
        highlightAccent = Color(0xFFA855F7),
        textPrimary = Color(0xFFFAF5FF),
        textSecondary = Color(0xFFE9D5FF),
        textMuted = Color(0xFFC084FC),
        isLight = false
    )

    // 19. Silver – فضي ورمادي
    val Silver = BarqThemePalette(
        themeId = BarqThemeId.SILVER,
        background = Color(0xFFEEF2F6),
        surface = Color(0xFFF8FAFC),
        card = Color(0xFFFFFFFF),
        cardElevated = Color(0xFFE2E8F0),
        border = Color(0xFF94A3B8),
        primaryAccent = Color(0xFF334155),
        primaryAccentDim = Color(0xFF1E293B),
        secondaryAccent = Color(0xFF0284C7),
        secondaryAccentDim = Color(0xFF0369A1),
        tertiaryAccent = Color(0xFF0D9488),
        tertiarySoft = Color(0xFFCCFBF1),
        dangerAccent = Color(0xFFE11D48),
        highlightAccent = Color(0xFF475569),
        textPrimary = Color(0xFF0F172A),
        textSecondary = Color(0xFF334155),
        textMuted = Color(0xFF64748B),
        isLight = true
    )

    // 20. Copper – نحاسي وبني
    val Copper = BarqThemePalette(
        themeId = BarqThemeId.COPPER,
        background = Color(0xFF120B07),
        surface = Color(0xFF1F130C),
        card = Color(0xFF2E1C12),
        cardElevated = Color(0xFF402719),
        border = Color(0xFF7C4728),
        primaryAccent = Color(0xFFFB923C),
        primaryAccentDim = Color(0xFFEA580C),
        secondaryAccent = Color(0xFFFBBF24),
        secondaryAccentDim = Color(0xFFD97706),
        tertiaryAccent = Color(0xFFFDBA74),
        tertiarySoft = Color(0xFF432612),
        dangerAccent = Color(0xFFEF4444),
        highlightAccent = Color(0xFFF59E0B),
        textPrimary = Color(0xFFFFF7ED),
        textSecondary = Color(0xFFFED7AA),
        textMuted = Color(0xFFFB923C),
        isLight = false
    )

    // 21. Lavender – بنفسجي فاتح وأبيض
    val Lavender = BarqThemePalette(
        themeId = BarqThemeId.LAVENDER,
        background = Color(0xFFF5F3FF),
        surface = Color(0xFFFFFFFF),
        card = Color(0xFFFAF8FF),
        cardElevated = Color(0xFFEDE9FE),
        border = Color(0xFFC4B5FD),
        primaryAccent = Color(0xFF6D28D9),
        primaryAccentDim = Color(0xFF5B21B6),
        secondaryAccent = Color(0xFF9333EA),
        secondaryAccentDim = Color(0xFF7E22CE),
        tertiaryAccent = Color(0xFF0284C7),
        tertiarySoft = Color(0xFFE0F2FE),
        dangerAccent = Color(0xFFE11D48),
        highlightAccent = Color(0xFF8B5CF6),
        textPrimary = Color(0xFF1E1B4B),
        textSecondary = Color(0xFF4C1D95),
        textMuted = Color(0xFF6D28D9),
        isLight = true
    )

    // 22. Mint – أخضر نعناعي
    val Mint = BarqThemePalette(
        themeId = BarqThemeId.MINT,
        background = Color(0xFF041714),
        surface = Color(0xFF082621),
        card = Color(0xFF0E362F),
        cardElevated = Color(0xFF164A41),
        border = Color(0xFF2DD4BF),
        primaryAccent = Color(0xFF5EEAD4),
        primaryAccentDim = Color(0xFF14B8A6),
        secondaryAccent = Color(0xFF6EE7B7),
        secondaryAccentDim = Color(0xFF10B981),
        tertiaryAccent = Color(0xFF38BDF8),
        tertiarySoft = Color(0xFF0F3146),
        dangerAccent = Color(0xFFFB7185),
        highlightAccent = Color(0xFF2DD4BF),
        textPrimary = Color(0xFFF0FDFA),
        textSecondary = Color(0xFF99F6E4),
        textMuted = Color(0xFF5EEAD4),
        isLight = false
    )

    // 23. Cherry Blossom – وردي وأبيض
    val CherryBlossom = BarqThemePalette(
        themeId = BarqThemeId.CHERRY_BLOSSOM,
        background = Color(0xFFFFF1F5),
        surface = Color(0xFFFFFFFF),
        card = Color(0xFFFFF8FA),
        cardElevated = Color(0xFFFCE7F3),
        border = Color(0xFFF9A8D4),
        primaryAccent = Color(0xFFBE185D),
        primaryAccentDim = Color(0xFF9D174D),
        secondaryAccent = Color(0xFFDB2777),
        secondaryAccentDim = Color(0xFFBE185D),
        tertiaryAccent = Color(0xFF9333EA),
        tertiarySoft = Color(0xFFF3E8FF),
        dangerAccent = Color(0xFFE11D48),
        highlightAccent = Color(0xFFEC4899),
        textPrimary = Color(0xFF3B071E),
        textSecondary = Color(0xFF701A3E),
        textMuted = Color(0xFF9D174D),
        isLight = true
    )

    // 24. Midnight Black – أسود عميق وتفاصيل مضيئة
    val MidnightBlack = BarqThemePalette(
        themeId = BarqThemeId.MIDNIGHT_BLACK,
        background = Color(0xFF000000),
        surface = Color(0xFF07090E),
        card = Color(0xFF0D111A),
        cardElevated = Color(0xFF151B29),
        border = Color(0xFF2E3C56),
        primaryAccent = Color(0xFF00F0FF),
        primaryAccentDim = Color(0xFF00A8B5),
        secondaryAccent = Color(0xFF00E676),
        secondaryAccentDim = Color(0xFF00A152),
        tertiaryAccent = Color(0xFFFFD600),
        tertiarySoft = Color(0xFF2E2705),
        dangerAccent = Color(0xFFFF3366),
        highlightAccent = Color(0xFF7C4DFF),
        textPrimary = Color(0xFFFFFFFF),
        textSecondary = Color(0xFFCBD5E1),
        textMuted = Color(0xFF94A3B8),
        isLight = false
    )

    // 25. Desert Sand – رملي وذهبي
    val DesertSand = BarqThemePalette(
        themeId = BarqThemeId.DESERT_SAND,
        background = Color(0xFFFDF8EE),
        surface = Color(0xFFFFFFFF),
        card = Color(0xFFFFFCF5),
        cardElevated = Color(0xFFF5E9D0),
        border = Color(0xFFD6B885),
        primaryAccent = Color(0xFFB45309),
        primaryAccentDim = Color(0xFF92400E),
        secondaryAccent = Color(0xFF0F766E),
        secondaryAccentDim = Color(0xFF115E59),
        tertiaryAccent = Color(0xFFD97706),
        tertiarySoft = Color(0xFFFEF3C7),
        dangerAccent = Color(0xFFDC2626),
        highlightAccent = Color(0xFFC2410C),
        textPrimary = Color(0xFF271805),
        textSecondary = Color(0xFF5C3A10),
        textMuted = Color(0xFF855822),
        isLight = true
    )

    // 26. Galaxy – ألوان فضائية بنفسجية وزرقاء
    val Galaxy = BarqThemePalette(
        themeId = BarqThemeId.GALAXY,
        background = Color(0xFF050514),
        surface = Color(0xFF0B0B26),
        card = Color(0xFF13133B),
        cardElevated = Color(0xFF1D1D54),
        border = Color(0xFF4F46E5),
        primaryAccent = Color(0xFF818CF8),
        primaryAccentDim = Color(0xFF4F46E5),
        secondaryAccent = Color(0xFF38BDF8),
        secondaryAccentDim = Color(0xFF0284C7),
        tertiaryAccent = Color(0xFFE879F9),
        tertiarySoft = Color(0xFF321345),
        dangerAccent = Color(0xFFFB7185),
        highlightAccent = Color(0xFFC084FC),
        textPrimary = Color(0xFFF5F3FF),
        textSecondary = Color(0xFFC7D2FE),
        textMuted = Color(0xFF818CF8),
        isLight = false
    )

    fun buildCustomPalette(
        primaryColor: Color,
        secondaryColor: Color,
        backgroundColor: Color,
        isLightMode: Boolean,
        customCardColor: Color? = null,
        customButtonColor: Color? = null,
        customTextColor: Color? = null,
        customBorderColor: Color? = null
    ): BarqThemePalette {
        val safeBg = if (isLightMode && backgroundColor.luminance() < 0.55f) {
            Color(0xFFF8FAFC)
        } else if (!isLightMode && backgroundColor.luminance() > 0.45f) {
            Color(0xFF0B101B)
        } else {
            backgroundColor
        }
        val surface = if (isLightMode) {
            Color(0xFFFFFFFF)
        } else {
            blendColors(safeBg, Color.White, 0.06f)
        }
        val rawCard = customCardColor ?: if (isLightMode) {
            Color(0xFFFFFFFF)
        } else {
            blendColors(safeBg, primaryColor, 0.12f)
        }
        val card = if (isLightMode && rawCard.luminance() < 0.5f) {
            Color(0xFFFFFFFF)
        } else if (!isLightMode && rawCard.luminance() > 0.48f) {
            blendColors(safeBg, primaryColor, 0.12f)
        } else {
            rawCard
        }
        val cardElevated = if (isLightMode) {
            blendColors(Color(0xFFF1F5F9), primaryColor, 0.08f)
        } else {
            blendColors(card, Color.White, 0.08f)
        }
        val border = customBorderColor ?: if (isLightMode) {
            blendColors(Color(0xFFCBD5E1), primaryColor, 0.28f)
        } else {
            blendColors(cardElevated, primaryColor, 0.38f)
        }

        val defaultTextPrimary = if (isLightMode) Color(0xFF0F172A) else Color(0xFFF8FAFC)
        val textPrimary = if (customTextColor != null && calculateContrastRatio(customTextColor, card) >= 4.5) {
            customTextColor
        } else {
            defaultTextPrimary
        }
        val textSecondary = if (isLightMode) {
            blendColors(textPrimary, Color(0xFF475569), 0.35f)
        } else {
            blendColors(textPrimary, Color(0xFF94A3B8), 0.35f)
        }
        val textMuted = if (isLightMode) Color(0xFF64748B) else Color(0xFF94A3B8)
        val resolvedButtonColor = customButtonColor ?: primaryColor

        return BarqThemePalette(
            themeId = BarqThemeId.CUSTOM,
            background = safeBg,
            surface = surface,
            card = card,
            cardElevated = cardElevated,
            border = border,
            primaryAccent = primaryColor,
            primaryAccentDim = shiftColorBrightness(primaryColor, 0.75f),
            secondaryAccent = secondaryColor,
            secondaryAccentDim = shiftColorBrightness(secondaryColor, 0.75f),
            tertiaryAccent = Color(0xFFF59E0B),
            tertiarySoft = if (isLightMode) Color(0xFFFEF3C7) else Color(0xFF3B2A10),
            dangerAccent = if (isLightMode) Color(0xFFE11D48) else Color(0xFFF43F5E),
            highlightAccent = blendColors(primaryColor, secondaryColor, 0.5f),
            textPrimary = textPrimary,
            textSecondary = textSecondary,
            textMuted = textMuted,
            isLight = isLightMode,
            buttonColor = resolvedButtonColor
        )
    }

    fun forThemeId(
        themeId: BarqThemeId,
        customPrimary: Color = BarqThemeState.customPrimaryColor,
        customSecondary: Color = BarqThemeState.customSecondaryColor,
        customBackground: Color = BarqThemeState.customBackgroundColor,
        customIsLight: Boolean = BarqThemeState.customIsLight,
        customCard: Color? = BarqThemeState.customCardColor,
        customButton: Color? = BarqThemeState.customButtonColor,
        customText: Color? = BarqThemeState.customTextColor,
        customBorder: Color? = BarqThemeState.customBorderColor
    ): BarqThemePalette {
        return when (themeId) {
            BarqThemeId.MIDNIGHT_BLUE -> MidnightBlue
            BarqThemeId.CYBERPUNK -> Cyberpunk
            BarqThemeId.PURE_LIGHT -> PureLight
            BarqThemeId.EMERALD -> Emerald
            BarqThemeId.LUXURY_GOLD -> LuxuryGold
            BarqThemeId.GLASSMORPHISM -> Glassmorphism
            BarqThemeId.CRIMSON -> Crimson
            BarqThemeId.GRAPHITE -> Graphite
            BarqThemeId.ARCTIC_ICE -> ArcticIce
            BarqThemeId.OCEAN_DEEP -> OceanDeep
            BarqThemeId.SUNSET -> Sunset
            BarqThemeId.AURORA -> Aurora
            BarqThemeId.ROYAL_PURPLE -> RoyalPurple
            BarqThemeId.ROSE_PINK -> RosePink
            BarqThemeId.NEON_GREEN -> NeonGreen
            BarqThemeId.SAPPHIRE -> Sapphire
            BarqThemeId.RUBY_RED -> RubyRed
            BarqThemeId.AMETHYST -> Amethyst
            BarqThemeId.SILVER -> Silver
            BarqThemeId.COPPER -> Copper
            BarqThemeId.LAVENDER -> Lavender
            BarqThemeId.MINT -> Mint
            BarqThemeId.CHERRY_BLOSSOM -> CherryBlossom
            BarqThemeId.MIDNIGHT_BLACK -> MidnightBlack
            BarqThemeId.DESERT_SAND -> DesertSand
            BarqThemeId.GALAXY -> Galaxy
            BarqThemeId.CUSTOM -> buildCustomPalette(
                primaryColor = customPrimary,
                secondaryColor = customSecondary,
                backgroundColor = customBackground,
                isLightMode = customIsLight,
                customCardColor = customCard,
                customButtonColor = customButton,
                customTextColor = customText,
                customBorderColor = customBorder
            )
        }
    }
}

/**
 * Keyframes and interpolation logic for the 10 professional Animated Themes.
 */
object BarqAnimatedThemes {
    fun keyframesFor(animId: BarqAnimatedThemeId): List<BarqThemePalette> {
        return when (animId) {
            BarqAnimatedThemeId.NONE -> listOf(BarqThemePalettes.MidnightBlue)
            BarqAnimatedThemeId.AURORA_FLOW -> listOf(
                BarqThemePalettes.Aurora,
                BarqThemePalettes.Emerald.copy(
                    themeId = BarqThemeId.AURORA,
                    primaryAccent = Color(0xFF00E5FF),
                    secondaryAccent = Color(0xFF10B981),
                    tertiaryAccent = Color(0xFFC084FC)
                ),
                BarqThemePalettes.Glassmorphism.copy(
                    themeId = BarqThemeId.AURORA,
                    primaryAccent = Color(0xFFA855F7),
                    secondaryAccent = Color(0xFF2EE59D),
                    border = Color(0xFF7F5AF0)
                )
            )
            BarqAnimatedThemeId.GALAXY_MOTION -> listOf(
                BarqThemePalettes.Galaxy,
                BarqThemePalettes.Amethyst.copy(
                    themeId = BarqThemeId.GALAXY,
                    primaryAccent = Color(0xFFC084FC),
                    secondaryAccent = Color(0xFF60A5FA)
                ),
                BarqThemePalettes.Sapphire.copy(
                    themeId = BarqThemeId.GALAXY,
                    primaryAccent = Color(0xFF38BDF8),
                    secondaryAccent = Color(0xFFE879F9)
                )
            )
            BarqAnimatedThemeId.CYBER_PULSE -> listOf(
                BarqThemePalettes.Cyberpunk,
                BarqThemePalettes.Cyberpunk.copy(
                    primaryAccent = Color(0xFF00F0FF),
                    secondaryAccent = Color(0xFFFF2A85),
                    border = Color(0xFF00F0FF)
                ),
                BarqThemePalettes.RoyalPurple.copy(
                    themeId = BarqThemeId.CYBERPUNK,
                    primaryAccent = Color(0xFFFCEE09),
                    secondaryAccent = Color(0xFFFF2A85),
                    border = Color(0xFFA855F7)
                )
            )
            BarqAnimatedThemeId.OCEAN_WAVES -> listOf(
                BarqThemePalettes.OceanDeep,
                BarqThemePalettes.Glassmorphism.copy(themeId = BarqThemeId.OCEAN_DEEP),
                BarqThemePalettes.Mint.copy(
                    themeId = BarqThemeId.OCEAN_DEEP,
                    primaryAccent = Color(0xFF2DD4BF),
                    secondaryAccent = Color(0xFF38BDF8)
                )
            )
            BarqAnimatedThemeId.NEON_SPECTRUM -> listOf(
                BarqThemePalettes.NeonGreen,
                BarqThemePalettes.MidnightBlack.copy(
                    themeId = BarqThemeId.NEON_GREEN,
                    primaryAccent = Color(0xFF00F0FF),
                    secondaryAccent = Color(0xFF39FF14),
                    border = Color(0xFF00F0FF)
                ),
                BarqThemePalettes.Cyberpunk.copy(
                    themeId = BarqThemeId.NEON_GREEN,
                    primaryAccent = Color(0xFFFF2A85),
                    secondaryAccent = Color(0xFFFCEE09)
                )
            )
            BarqAnimatedThemeId.SUNSET_MOTION -> listOf(
                BarqThemePalettes.Sunset,
                BarqThemePalettes.Crimson.copy(
                    themeId = BarqThemeId.SUNSET,
                    primaryAccent = Color(0xFFFB923C),
                    secondaryAccent = Color(0xFFF43F5E)
                ),
                BarqThemePalettes.RosePink.copy(
                    themeId = BarqThemeId.SUNSET,
                    primaryAccent = Color(0xFFFF6B9D),
                    secondaryAccent = Color(0xFFFFB26B)
                )
            )
            BarqAnimatedThemeId.EMERALD_PULSE -> listOf(
                BarqThemePalettes.Emerald,
                BarqThemePalettes.Mint.copy(themeId = BarqThemeId.EMERALD),
                BarqThemePalettes.Aurora.copy(
                    themeId = BarqThemeId.EMERALD,
                    primaryAccent = Color(0xFF34D399),
                    secondaryAccent = Color(0xFF2DD4BF)
                )
            )
            BarqAnimatedThemeId.GOLDEN_LUXURY -> listOf(
                BarqThemePalettes.LuxuryGold,
                BarqThemePalettes.Copper.copy(
                    themeId = BarqThemeId.LUXURY_GOLD,
                    primaryAccent = Color(0xFFFBBF24),
                    secondaryAccent = Color(0xFFFB923C)
                ),
                BarqThemePalettes.LuxuryGold.copy(
                    primaryAccent = Color(0xFFFDE047),
                    secondaryAccent = Color(0xFFF59E0B),
                    border = Color(0xFFD97706)
                )
            )
            BarqAnimatedThemeId.RAINBOW_FLOW -> listOf(
                BarqThemePalettes.MidnightBlue,
                BarqThemePalettes.Emerald.copy(themeId = BarqThemeId.GLASSMORPHISM),
                BarqThemePalettes.Sunset.copy(themeId = BarqThemeId.GLASSMORPHISM),
                BarqThemePalettes.Galaxy.copy(themeId = BarqThemeId.GLASSMORPHISM)
            )
            BarqAnimatedThemeId.FLAME_MOTION -> listOf(
                BarqThemePalettes.Crimson,
                BarqThemePalettes.RubyRed.copy(
                    themeId = BarqThemeId.CRIMSON,
                    primaryAccent = Color(0xFFFF5722),
                    secondaryAccent = Color(0xFFFFC107)
                ),
                BarqThemePalettes.Copper.copy(
                    themeId = BarqThemeId.CRIMSON,
                    primaryAccent = Color(0xFFFF3355),
                    secondaryAccent = Color(0xFFFB923C)
                )
            )
        }
    }

    fun resolveAnimatedPalette(
        animId: BarqAnimatedThemeId,
        phase: Float
    ): BarqThemePalette {
        val frames = keyframesFor(animId)
        if (frames.isEmpty()) return BarqThemePalettes.MidnightBlue
        if (frames.size == 1) return frames.first()
        val normalized = ((phase % 1f) + 1f) % 1f
        val scaled = normalized * frames.size
        val index = scaled.toInt() % frames.size
        val nextIndex = (index + 1) % frames.size
        val localFraction = scaled - scaled.toInt()
        return lerpPalette(frames[index], frames[nextIndex], localFraction)
    }
}

/**
 * Global reactive theme state manager backed by SharedPreferences ("barq_theme_prefs")
 * so theme choices, animated themes, animation speed, custom colors, auto light/dark mode,
 * and layout direction persist across app restarts and load BEFORE the very first UI frame.
 */
object BarqThemeState {
    private const val PREFS_NAME = "barq_theme_prefs"
    private const val KEY_THEME_ID = "selected_theme_id"
    private const val KEY_ANIMATED_THEME_ID = "selected_animated_theme_id"
    private const val KEY_ANIMATION_ENABLED = "theme_animation_enabled"
    private const val KEY_ANIMATION_SPEED = "theme_animation_speed"
    private const val KEY_RESPECT_REDUCE_MOTION = "respect_reduce_motion"
    private const val KEY_BRIGHTNESS_MODE = "theme_brightness_mode"
    private const val KEY_AUTO_SYSTEM = "auto_system_mode"
    private const val KEY_CUSTOM_PRIMARY = "custom_primary_argb"
    private const val KEY_CUSTOM_SECONDARY = "custom_secondary_argb"
    private const val KEY_CUSTOM_BG = "custom_bg_argb"
    private const val KEY_CUSTOM_CARD = "custom_card_argb"
    private const val KEY_CUSTOM_BUTTON = "custom_button_argb"
    private const val KEY_CUSTOM_TEXT = "custom_text_argb"
    private const val KEY_CUSTOM_BORDER = "custom_border_argb"
    private const val KEY_CUSTOM_IS_LIGHT = "custom_is_light"
    private const val KEY_LAYOUT_DIRECTION = "layout_direction_mode"

    var selectedThemeId by mutableStateOf(BarqThemeId.MIDNIGHT_BLUE)
        private set

    var selectedAnimatedThemeId by mutableStateOf(BarqAnimatedThemeId.NONE)
        private set

    var isThemeAnimationEnabled by mutableStateOf(true)
        private set

    var animationSpeed by mutableStateOf(BarqAnimationSpeed.MEDIUM)
        private set

    var respectSystemReduceMotion by mutableStateOf(true)
        private set

    var brightnessMode by mutableStateOf(BarqThemeBrightnessMode.THEME_DEFAULT)
        private set

    var isAppInForeground by mutableStateOf(true)
        internal set

    var animationPhase by mutableFloatStateOf(0f)
        internal set

    var autoSystemDarkLightMode by mutableStateOf(false)
        private set

    var customPrimaryColor by mutableStateOf(Color(0xFF38BDF8))
        private set

    var customSecondaryColor by mutableStateOf(Color(0xFF10B981))
        private set

    var customBackgroundColor by mutableStateOf(Color(0xFF081020))
        private set

    var customCardColor by mutableStateOf(Color(0xFF131F38))
        private set

    var customButtonColor by mutableStateOf(Color(0xFF38BDF8))
        private set

    var customTextColor by mutableStateOf(Color(0xFFF8FAFC))
        private set

    var customBorderColor by mutableStateOf(Color(0xFF263B63))
        private set

    var customIsLight by mutableStateOf(false)
        private set

    var layoutDirection by mutableStateOf(LayoutDirection.Rtl)
        private set

    var activePalette by mutableStateOf(BarqThemePalettes.MidnightBlue)
        internal set

    private var isInitializedFromPrefs = false

    internal fun resetInitializationFlagForTesting() {
        isInitializedFromPrefs = false
        selectedThemeId = BarqThemeId.MIDNIGHT_BLUE
        activePalette = BarqThemePalettes.MidnightBlue
    }

    fun ensureInitialized(context: Context) {
        if (!isInitializedFromPrefs) {
            loadFromPreferences(context)
        }
    }

    fun loadFromPreferences(context: Context) {
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val savedId = BarqThemeId.fromKey(prefs.getString(KEY_THEME_ID, BarqThemeId.MIDNIGHT_BLUE.storageKey))
            val savedAnimId = BarqAnimatedThemeId.fromKey(prefs.getString(KEY_ANIMATED_THEME_ID, BarqAnimatedThemeId.NONE.storageKey))
            val animEnabled = prefs.getBoolean(KEY_ANIMATION_ENABLED, true)
            val animSpeed = BarqAnimationSpeed.fromKey(prefs.getString(KEY_ANIMATION_SPEED, BarqAnimationSpeed.MEDIUM.storageKey))
            val respectMotion = prefs.getBoolean(KEY_RESPECT_REDUCE_MOTION, true)
            val brightMode = BarqThemeBrightnessMode.fromKey(prefs.getString(KEY_BRIGHTNESS_MODE, BarqThemeBrightnessMode.THEME_DEFAULT.storageKey))
            val autoMode = prefs.getBoolean(KEY_AUTO_SYSTEM, false)

            val cPrim = Color(prefs.getInt(KEY_CUSTOM_PRIMARY, Color(0xFF38BDF8).toArgb()))
            val cSec = Color(prefs.getInt(KEY_CUSTOM_SECONDARY, Color(0xFF10B981).toArgb()))
            val cBg = Color(prefs.getInt(KEY_CUSTOM_BG, Color(0xFF081020).toArgb()))
            val cCard = Color(prefs.getInt(KEY_CUSTOM_CARD, Color(0xFF131F38).toArgb()))
            val cBtn = Color(prefs.getInt(KEY_CUSTOM_BUTTON, cPrim.toArgb()))
            val cTxt = Color(prefs.getInt(KEY_CUSTOM_TEXT, Color(0xFFF8FAFC).toArgb()))
            val cBrd = Color(prefs.getInt(KEY_CUSTOM_BORDER, Color(0xFF263B63).toArgb()))
            val cLight = prefs.getBoolean(KEY_CUSTOM_IS_LIGHT, false)
            val dirStr = prefs.getString(KEY_LAYOUT_DIRECTION, "RTL") ?: "RTL"

            val isSysDark = try {
                val nightMask = context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
                nightMask != Configuration.UI_MODE_NIGHT_NO
            } catch (_: Exception) {
                true
            }

            selectedThemeId = savedId
            selectedAnimatedThemeId = savedAnimId
            isThemeAnimationEnabled = animEnabled
            animationSpeed = animSpeed
            respectSystemReduceMotion = respectMotion
            brightnessMode = brightMode
            autoSystemDarkLightMode = autoMode
            customPrimaryColor = cPrim
            customSecondaryColor = cSec
            customBackgroundColor = cBg
            customCardColor = cCard
            customButtonColor = cBtn
            customTextColor = cTxt
            customBorderColor = cBrd
            customIsLight = cLight
            layoutDirection = if (dirStr.equals("LTR", ignoreCase = true)) LayoutDirection.Ltr else LayoutDirection.Rtl
            activePalette = resolvePalette(systemInDarkTheme = isSysDark, phase = animationPhase)
            isInitializedFromPrefs = true
        } catch (_: Exception) {
        }
    }

    fun isSystemReduceMotionActive(context: Context): Boolean {
        return try {
            val animScale = Settings.Global.getFloat(
                context.contentResolver,
                Settings.Global.ANIMATOR_DURATION_SCALE,
                1f
            )
            val transitionScale = Settings.Global.getFloat(
                context.contentResolver,
                Settings.Global.TRANSITION_ANIMATION_SCALE,
                1f
            )
            animScale == 0f || transitionScale == 0f
        } catch (_: Exception) {
            false
        }
    }

    fun shouldAnimateActiveTheme(context: Context): Boolean {
        if (selectedAnimatedThemeId == BarqAnimatedThemeId.NONE) return false
        if (!isThemeAnimationEnabled) return false
        if (!isAppInForeground) return false
        if (respectSystemReduceMotion && isSystemReduceMotionActive(context)) return false
        return true
    }

    fun setAppForegroundState(inForeground: Boolean) {
        isAppInForeground = inForeground
    }

    fun resolvePalette(systemInDarkTheme: Boolean, phase: Float = animationPhase): BarqThemePalette {
        if (autoSystemDarkLightMode) {
            return if (systemInDarkTheme) {
                val darkChoice = if (selectedThemeId == BarqThemeId.PURE_LIGHT) {
                    BarqThemeId.MIDNIGHT_BLUE
                } else {
                    selectedThemeId
                }
                val raw = if (selectedAnimatedThemeId != BarqAnimatedThemeId.NONE) {
                    BarqAnimatedThemes.resolveAnimatedPalette(selectedAnimatedThemeId, phase)
                } else {
                    BarqThemePalettes.forThemeId(
                        themeId = darkChoice,
                        customPrimary = customPrimaryColor,
                        customSecondary = customSecondaryColor,
                        customBackground = customBackgroundColor,
                        customIsLight = false,
                        customCard = customCardColor,
                        customButton = customButtonColor,
                        customText = customTextColor,
                        customBorder = customBorderColor
                    )
                }
                adaptPaletteForBrightness(raw, targetIsLight = false)
            } else {
                BarqThemePalettes.PureLight
            }
        }

        val rawPalette = if (selectedAnimatedThemeId != BarqAnimatedThemeId.NONE) {
            BarqAnimatedThemes.resolveAnimatedPalette(selectedAnimatedThemeId, phase)
        } else {
            BarqThemePalettes.forThemeId(
                themeId = selectedThemeId,
                customPrimary = customPrimaryColor,
                customSecondary = customSecondaryColor,
                customBackground = customBackgroundColor,
                customIsLight = customIsLight,
                customCard = customCardColor,
                customButton = customButtonColor,
                customText = customTextColor,
                customBorder = customBorderColor
            )
        }

        return when (brightnessMode) {
            BarqThemeBrightnessMode.THEME_DEFAULT -> rawPalette
            BarqThemeBrightnessMode.DARK -> adaptPaletteForBrightness(rawPalette, targetIsLight = false)
            BarqThemeBrightnessMode.LIGHT -> adaptPaletteForBrightness(rawPalette, targetIsLight = true)
        }
    }

    fun applyTheme(context: Context, themeId: BarqThemeId, disableAutoMode: Boolean = true) {
        selectedThemeId = themeId
        selectedAnimatedThemeId = BarqAnimatedThemeId.NONE
        if (disableAutoMode) {
            autoSystemDarkLightMode = false
        }
        val base = BarqThemePalettes.forThemeId(
            themeId = themeId,
            customPrimary = customPrimaryColor,
            customSecondary = customSecondaryColor,
            customBackground = customBackgroundColor,
            customIsLight = customIsLight,
            customCard = customCardColor,
            customButton = customButtonColor,
            customText = customTextColor,
            customBorder = customBorderColor
        )
        activePalette = when (brightnessMode) {
            BarqThemeBrightnessMode.THEME_DEFAULT -> base
            BarqThemeBrightnessMode.DARK -> adaptPaletteForBrightness(base, targetIsLight = false)
            BarqThemeBrightnessMode.LIGHT -> adaptPaletteForBrightness(base, targetIsLight = true)
        }
        saveToPreferences(context)
    }

    fun applyAnimatedTheme(
        context: Context,
        animatedThemeId: BarqAnimatedThemeId,
        enableAnimation: Boolean = true
    ) {
        selectedAnimatedThemeId = animatedThemeId
        if (animatedThemeId != BarqAnimatedThemeId.NONE) {
            selectedThemeId = animatedThemeId.baseThemeId
            isThemeAnimationEnabled = enableAnimation
            autoSystemDarkLightMode = false
        }
        activePalette = resolvePalette(systemInDarkTheme = true, phase = animationPhase)
        saveToPreferences(context)
    }

    fun setThemeAnimationEnabled(context: Context, enabled: Boolean) {
        isThemeAnimationEnabled = enabled
        activePalette = resolvePalette(systemInDarkTheme = true, phase = animationPhase)
        saveToPreferences(context)
    }

    fun setThemeAnimationSpeed(context: Context, speed: BarqAnimationSpeed) {
        animationSpeed = speed
        saveToPreferences(context)
    }

    fun setRespectReduceMotion(context: Context, respect: Boolean) {
        respectSystemReduceMotion = respect
        saveToPreferences(context)
    }

    fun setThemeBrightnessMode(context: Context, mode: BarqThemeBrightnessMode, isSystemDarkNow: Boolean = true) {
        brightnessMode = mode
        if (mode != BarqThemeBrightnessMode.THEME_DEFAULT) {
            autoSystemDarkLightMode = false
        }
        activePalette = resolvePalette(isSystemDarkNow, animationPhase)
        saveToPreferences(context)
    }

    fun setAutoSystemMode(context: Context, enabled: Boolean, isSystemDarkNow: Boolean = true) {
        autoSystemDarkLightMode = enabled
        if (enabled) {
            brightnessMode = BarqThemeBrightnessMode.THEME_DEFAULT
        }
        activePalette = resolvePalette(isSystemDarkNow, animationPhase)
        saveToPreferences(context)
    }

    fun updateCustomTheme(
        context: Context,
        primary: Color = customPrimaryColor,
        secondary: Color = customSecondaryColor,
        background: Color = customBackgroundColor,
        isLight: Boolean = customIsLight,
        card: Color = if (isLight) Color(0xFFFFFFFF) else blendColors(background, primary, 0.12f),
        button: Color = primary,
        text: Color = if (isLight) Color(0xFF0F172A) else Color(0xFFF8FAFC),
        border: Color = if (isLight) blendColors(Color(0xFFCBD5E1), primary, 0.28f) else blendColors(card, primary, 0.38f),
        applyImmediately: Boolean = true
    ) {
        customPrimaryColor = primary
        customSecondaryColor = secondary
        customBackgroundColor = background
        customCardColor = card
        customButtonColor = button
        customTextColor = text
        customBorderColor = border
        customIsLight = isLight
        if (applyImmediately) {
            selectedThemeId = BarqThemeId.CUSTOM
            selectedAnimatedThemeId = BarqAnimatedThemeId.NONE
            autoSystemDarkLightMode = false
            brightnessMode = BarqThemeBrightnessMode.THEME_DEFAULT
            activePalette = BarqThemePalettes.buildCustomPalette(
                primaryColor = primary,
                secondaryColor = secondary,
                backgroundColor = background,
                isLightMode = isLight,
                customCardColor = card,
                customButtonColor = button,
                customTextColor = text,
                customBorderColor = border
            )
        }
        saveToPreferences(context)
    }

    fun resetCustomThemeDefaults(context: Context, applyNow: Boolean = false) {
        customPrimaryColor = Color(0xFF38BDF8)
        customSecondaryColor = Color(0xFF10B981)
        customBackgroundColor = Color(0xFF081020)
        customCardColor = Color(0xFF131F38)
        customButtonColor = Color(0xFF38BDF8)
        customTextColor = Color(0xFFF8FAFC)
        customBorderColor = Color(0xFF263B63)
        customIsLight = false
        if (applyNow || selectedThemeId == BarqThemeId.CUSTOM) {
            activePalette = BarqThemePalettes.buildCustomPalette(
                primaryColor = customPrimaryColor,
                secondaryColor = customSecondaryColor,
                backgroundColor = customBackgroundColor,
                isLightMode = customIsLight,
                customCardColor = customCardColor,
                customButtonColor = customButtonColor,
                customTextColor = customTextColor,
                customBorderColor = customBorderColor
            )
        }
        saveToPreferences(context)
    }

    fun resetToDefaultTheme(context: Context) {
        selectedThemeId = BarqThemeId.MIDNIGHT_BLUE
        selectedAnimatedThemeId = BarqAnimatedThemeId.NONE
        isThemeAnimationEnabled = true
        animationSpeed = BarqAnimationSpeed.MEDIUM
        brightnessMode = BarqThemeBrightnessMode.THEME_DEFAULT
        autoSystemDarkLightMode = false
        customPrimaryColor = Color(0xFF38BDF8)
        customSecondaryColor = Color(0xFF10B981)
        customBackgroundColor = Color(0xFF081020)
        customCardColor = Color(0xFF131F38)
        customButtonColor = Color(0xFF38BDF8)
        customTextColor = Color(0xFFF8FAFC)
        customBorderColor = Color(0xFF263B63)
        customIsLight = false
        activePalette = BarqThemePalettes.MidnightBlue
        saveToPreferences(context)
    }

    fun setLayoutDirectionMode(context: Context, direction: LayoutDirection) {
        layoutDirection = direction
        saveToPreferences(context)
    }

    private fun saveToPreferences(context: Context) {
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putString(KEY_THEME_ID, selectedThemeId.storageKey)
                .putString(KEY_ANIMATED_THEME_ID, selectedAnimatedThemeId.storageKey)
                .putBoolean(KEY_ANIMATION_ENABLED, isThemeAnimationEnabled)
                .putString(KEY_ANIMATION_SPEED, animationSpeed.storageKey)
                .putBoolean(KEY_RESPECT_REDUCE_MOTION, respectSystemReduceMotion)
                .putString(KEY_BRIGHTNESS_MODE, brightnessMode.storageKey)
                .putBoolean(KEY_AUTO_SYSTEM, autoSystemDarkLightMode)
                .putInt(KEY_CUSTOM_PRIMARY, customPrimaryColor.toArgb())
                .putInt(KEY_CUSTOM_SECONDARY, customSecondaryColor.toArgb())
                .putInt(KEY_CUSTOM_BG, customBackgroundColor.toArgb())
                .putInt(KEY_CUSTOM_CARD, customCardColor.toArgb())
                .putInt(KEY_CUSTOM_BUTTON, customButtonColor.toArgb())
                .putInt(KEY_CUSTOM_TEXT, customTextColor.toArgb())
                .putInt(KEY_CUSTOM_BORDER, customBorderColor.toArgb())
                .putBoolean(KEY_CUSTOM_IS_LIGHT, customIsLight)
                .putString(KEY_LAYOUT_DIRECTION, if (layoutDirection == LayoutDirection.Ltr) "LTR" else "RTL")
                .apply()
            isInitializedFromPrefs = true
        } catch (_: Exception) {
        }
    }
}

// Reactive Palette Tokens used across all Barq P2P screens & components
val MidnightBg: Color
    get() = BarqThemeState.activePalette.background

val MidnightSurface: Color
    get() = BarqThemeState.activePalette.surface

val MidnightCard: Color
    get() = BarqThemeState.activePalette.card

val MidnightCardElevated: Color
    get() = BarqThemeState.activePalette.cardElevated

val GlassBorder: Color
    get() = BarqThemeState.activePalette.border

// Accents
val ElectricCyan: Color
    get() = BarqThemeState.activePalette.primaryAccent

val ElectricCyanDim: Color
    get() = BarqThemeState.activePalette.primaryAccentDim

val NeonEmerald: Color
    get() = BarqThemeState.activePalette.secondaryAccent

val NeonEmeraldDim: Color
    get() = BarqThemeState.activePalette.secondaryAccentDim

val HotspotAmber: Color
    get() = BarqThemeState.activePalette.tertiaryAccent

val HotspotAmberSoft: Color
    get() = BarqThemeState.activePalette.tertiarySoft

val CoralRose: Color
    get() = BarqThemeState.activePalette.dangerAccent

val RoyalViolet: Color
    get() = BarqThemeState.activePalette.highlightAccent

val ButtonAccent: Color
    get() = BarqThemeState.activePalette.buttonColor

// Text Colors
val TextPrimary: Color
    get() = BarqThemeState.activePalette.textPrimary

val TextSecondary: Color
    get() = BarqThemeState.activePalette.textSecondary

val TextMuted: Color
    get() = BarqThemeState.activePalette.textMuted

val OnPrimaryAccent: Color
    get() = BarqThemeState.activePalette.onPrimaryAccent

val OnSecondaryAccent: Color
    get() = BarqThemeState.activePalette.onSecondaryAccent

val OnTertiaryAccent: Color
    get() = BarqThemeState.activePalette.onTertiaryAccent

val OnButtonAccent: Color
    get() = BarqThemeState.activePalette.onButtonColor
